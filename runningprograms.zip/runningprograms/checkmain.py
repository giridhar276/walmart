


print(__name__)
