class Employee:
    ''' this is the Employee help'''
    def displayEmployee(self):
        print("this is the display func()")
    
        
if __name__ == "__main__": 
    emp1 = Employee()
    emp1.displayEmployee()
    print(Employee.__doc__) 