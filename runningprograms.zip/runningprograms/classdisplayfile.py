

class File:
    def __init__(self,filename):
        self.filename = filename
    def displayData(self):
        with open(self.filename,"r")as fobj:
            for line in fobj:
                print(line)
            
    
if __name__ == "__main__":
    file = File("realestate.csv")
    file.displayData()
