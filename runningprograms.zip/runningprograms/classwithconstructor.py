class Employee:
    ''' this is the Employee help'''
    # constructor
    def __init__(self,name):
        self.name = name
    def displayEmployee(self):
        print("Employee name :", self.name)
    
        
if __name__ == "__main__": 
    emp1 = Employee("Ram")
    emp1.displayEmployee()
    
    emp2 = Employee("Rita")
    emp2.displayEmployee() 
