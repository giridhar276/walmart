

#### dipslaying all the available isntances
import boto3

region = 'ap-south-1'
ec2_con_re = boto3.resource('ec2','ap-south-1')

for instance in ec2_con_re.instances.all():
    print(instance.id)




 ### terminating the instance
import boto3
ec2 = boto3.resource('ec2','ap-south-1')

instnace_ids = ["i-0f80db26f68646fa8","i-064f9db4cb4dee186"]
for instance_id in instnace_ids:
    instance = ec2.Instance(instance_id)
    response = instance.terminate()
    print(response)
