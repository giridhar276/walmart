
 
print( 1 + 3)

# two strings
 