    
import requests
import json
 
server = "https://api.github.com"
url = server + "/repos"
user = "giridharpython"
print("checking ", url, "using user:", user)

 
payload = {
  "name": "Hello-World",
  "description": "This is your first repository",
  "homepage": "https://api.github.com",
  "private": True,
  "has_issues": True,
  "has_projects": True,
  "has_wiki": True
}
r1 = requests.post(url, data=json.dumps(payload), auth=(user,'Nolimits1@'))
print(r1.json())
