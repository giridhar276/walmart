import requests
import json
import os
server = "https://api.github.com"
url = server + "/gists"
user = "giridharpython"
print("checking ", url, "using user:", user)


files = {
    "description": "2nd test",
    "public": "true",
    "user" : user,
    "files" : {}
}
for file in os.listdir():
    with open(file) as fobj:
        content = fobj.read()     
        files["files"].update({file :{ "content":content}})
r1 = requests.post(url, data=json.dumps(files), auth=(user,'5e42667d35538cb903f14852ddd841296bbbafd1'))
print(r1.json())
