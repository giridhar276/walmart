import requests
import json
server = "https://api.github.com"
url = server + "/gists"
user = "giridharpython"

local_file = "classdisplayfile.py"
with open(local_file) as fh:
    mydata = fh.read()
payload = {
    "description": "rest api - giri testing",
    "public": "true",
    "user" : user,
    "files": {
    local_file: {
    "content": mydata
        }
      }
}
r1 = requests.post(url, data=json.dumps(payload), auth=(user,'97d5fe08be91bc0e6aea4cad48561f1cf322bc88'))
#print(r1.json())

for key in r1.json():
    print(key)
    print(r1.json()[key])
    print("-------------------------")
    