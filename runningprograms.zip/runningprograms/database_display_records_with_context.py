# with context manager

import pymysql

with pymysql.connect(host="localhost",port = 3306,user="root",password = "password",database = "boa") as db:

    query = "select * from realestate"
    # executing the query
    db.execute(query)
    # displaying all the records
    # every record is a tuple
    for record in db.fetchall():
        print("Street :", record[0])
        print("City   :", record[1])
        print("------------------")
    
