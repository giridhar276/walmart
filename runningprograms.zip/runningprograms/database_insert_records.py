# insert query
# with context manager
import pymysql
import csv
with pymysql.connect(host="localhost",port = 3306,user="root",password = "password",database = "boa") as db:
    with open("realestate.csv","r") as fobj:
        reader = csv.reader(fobj)
        for line in reader:
            print(line)
            query = "insert into realestate values('{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}', \
                            '{}')".format(*line)
            # executing the query
            db.execute(query)
            print(db.rowcount , "record inserted")
    
