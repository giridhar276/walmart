import pymysql

db = pymysql.connect(host="localhost",port = 3306,user="root",password = "password",database = "boa")

#print(db)
# creating cursor for navigating
cursor = db.cursor()
# query
query = "select * from realestate"
# executing the query
cursor.execute(query)
# displaying all the records
# every record is a tuple
for record in cursor.fetchall():
    print("Street :", record[0])
    print("City   :", record[1])
    print("------------------")
    
db.close()    
