



def display(a,b):
    print(a,b)

display()    
