import pdb
pdb.set_trace()
colors = [
{
"colors": "red",
"values": "#f00"
},
{
"colors": "green",
"values": "#0f0"
},
]

for item in colors:
    print(item["colors"].ljust(10),item["values"])
