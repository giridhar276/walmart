book = {"chap1":10 , "chap2":20 , "chap3":30}

print(book)

print(book["chap1"])  # 10

print(book["chap2"])  # 20

#print(book["chap4"])


book = {"chap1":[10,"Eric","UK"] , "chap2":[20,"john","US"] }

print(book["chap1"][0])

book["chap1"] = 100

print("after replacing :", book)


