

book = {"chap1":10 ,"chap2":20 ,"chap3":30}

print(book)

## adding new key-value to the dictionary
book["chap4"] = 40
book["chap1"] = 1000

print("After adding :", book)

print("Only keys :", book.keys())
print("Only values:", book.values())
print("key-value items:", book.items())

print(book["chap4"]) # 40
#print(book["chap5"]) # will throw error .comment it
print(book.get("chap5"))  # None
print(book.get("chap5","something default"))
# remove key-value pair
book.pop("chap1")
print("Afte pop :", book)
book.pop("chap3")
print("Afte pop :", book)

book.popitem()  # remove random key-value pair
print("Afte popitem() :", book)

print(book.fromkeys("chap1"))

bdict = {"chap10":10}
book.update(bdict)
print("After update :", book)




