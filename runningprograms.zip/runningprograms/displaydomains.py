alist = ["google","oracle","microsoft"]

for host in alist:
    domain = "http://www"  + host + ".com"
    print(domain)
    
    
######
#2nd method  : using list comprehension
######    
    
domains =[ "http://www"  + host + ".com" for host in alist]   
print(domains)