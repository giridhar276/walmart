

import functions

functions.copyfile()

functions.readfile()

functions.deletefile()

functions.countfiles("C:\\Python37")
