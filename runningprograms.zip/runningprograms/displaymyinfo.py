import requests
import json
r = requests.get('https://api.github.com/users', auth=('giridharpython','Nolimits1@'))
print(r.text)



