infodoc =  { 2001: {"ap":70}  , 2002:{"tn":75} , 2003:{"up":50} }


print("state".ljust(10) , "literacy rate")
print("--------------------------")
for element in infodoc.values():
    key = list(element.keys())[0]
    value = list(element.values())[0]
    print(key.ljust(10) , value)
    
    
info = {
"id": "0001",
"type": "donut",
"name": "Cake",
"image":
{
"url": "images/0001.jpg",
"width": 200,
"height": 200
},
"thumbnail":
{
"url": "images/thumbnails/0001.jpg",
"width": 32,
"height": 32
}
}    

for key in info:
    if isinstance(info[key], dict):
        print(key.ljust(10), info[key]["url"])
    else:
        print(key.ljust(10) ,info[key])



