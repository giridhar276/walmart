

password = input("Enter password :")
print("password :", password)
