

# read operation  : reading line by line
with open("numbers.txt","r") as fobj:
    for line in fobj:
        line = line.strip()
        print(line)



# reading in list format ( all the lines in the list )
# [ line1 , line2 , line3 ]
with open("numbers.txt","r") as fobj:
    print(fobj.readlines())



# reading the whole file in string format
with open("numbers.txt","r") as fobj:
    print(fobj.read())
