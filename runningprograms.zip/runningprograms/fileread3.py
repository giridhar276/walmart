
 
try:
    
    # read operation  : reading line by line
    with open("Sacramentorealestatetransactionsfsdafasfsa.csv","r") as fobj:
        for line in fobj:
            line = line.strip()
            print(line)

    output = 1 + "hello"

except ValueError  as error:
    print("Invalid input")
    print("System error :", error)
except TypeError as error:
    print("Invalid operation")
    print("System error :", error)
except FileNotFoundError as error:
    print("File doesn't exist")
    print("System error :", error)
except Exception as error:
    print("Unknown exception")
    print("System error :", error)
