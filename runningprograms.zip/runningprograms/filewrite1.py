# read
# opening the file in write mode
# file will be created in the current directory
fobj = open("clients.txt","w")
fobj.write("python programming\n")
# closing the file
fobj.close()



fobj = open("numbers.txt","w")
for val in range(1,100):
    fobj.write(str(val) +  "\n")
# closing the file
fobj.close()



## method2  : context manager
with open("numbers.txt","w") as fobj:
   for val in range(1,100):
    fobj.write(str(val) +  "\n") 
