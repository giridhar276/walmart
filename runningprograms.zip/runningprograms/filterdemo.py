
alist = [10,3,434,5343,434,343]

print(list(filter( lambda x : x%2 ,alist)))
      
print(list(filter( lambda x : x%2 ==0 ,alist)))

alist = ["hello","hi","unix","shell"]
print(list(filter( lambda x : len(x)%2  ,alist)))
