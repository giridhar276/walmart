from flask import Flask, escape, request

app = Flask(__name__)

@app.route('/')
def hello():
    return "this is home page "

@app.route('/customers')
def customers():
    return "this is customers page "
 

@app.route('/clients')
def clients():
    return "this is clients page "
 

@app.route('/contactus')
def contactus():
    return "this is contactus page "



app.run(debug = True)