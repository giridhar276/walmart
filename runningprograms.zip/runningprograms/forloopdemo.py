# for with range()
for val in range(1,10):
    print(val)

# for with string
name= "python"
for char in name:
    print(char)

# for with list
alist =[10,20,30]
for val in alist:
    print(val)

# for with tuple
for val in (10,20,30):
    print(val)

# for with dictionary
adict = {"chap1":10 ,"chap2":20}
for key in adict:
    print(key)
    print(adict[key])
