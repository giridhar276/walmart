def copyfile():
    print("this is copyfile()")

def readfile():
    print("this is readfile()")

def deletefile():
    print("this is deletefile()")

def countfiles(path):
    print("Path :", path)


if __name__ == "__main__":
    copyfile()
    readfile()
    deletefile()
    countfiles("C:\\Python37 ")
