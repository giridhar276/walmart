name = input("Enter any name :")
print(name)
print(list(range(1,10)))
print(list(range(1,10,2)))
name = "python"
print(type(name))
print(isinstance(name,str)) # True
print(isinstance(name,list)) # False
print(id(name))  ## UNIQUE reference
alist=[102,40,40]
print(id(alist))
print(max(alist))
print(min(alist))
print(sum(alist))

atup = (10,20,30,40)
alist = list(atup)
alist[0] = 10000
atup = tuple(alist)
print("After replacing :", atup)

print(tuple(alist))

val = 10
print(str(val))

alist =[]   # empty list
alist = list()
atup = ()   # empty tuple
atup = tuple()
aset = set()   # empty set

