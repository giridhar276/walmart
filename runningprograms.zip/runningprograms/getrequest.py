

import requests
'''
response = requests.get("https://www.google.com")

print(response)
print(response.status_code)

print(response.text)
'''



### for github.com
response = requests.get("https://api.github.com/users/giridharpython")

print(response)
print(response.status_code)

