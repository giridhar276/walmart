

name = "python"

if name.isupper() :
    print("Inside if")
    print("String is upper")
else:
    print("inside else")
    
    
val = 10

if val < 10 :
    print("val is less than 10")
else:
    print("val is greater than 10")
    
    
    
    
    
    
    