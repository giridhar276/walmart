
# keyword arguments
def display(second,first):
    print(first,second)

# assignment is already done in the functioncall
display(first = 10 , second = 20)
