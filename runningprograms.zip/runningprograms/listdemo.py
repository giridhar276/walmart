# list

alist =[10,20,30,40,50,60,70]

print(alist)

print(alist[0])

print(alist[0:4])

print(alist[::-1])  # reversing

print(alist[::2])
# modifying the value
alist[0] = 1000

print("After replacing :", alist)