alist = [10,20,30,40,50,56,10,2]
# appending  : used for 1 single object
alist.append(60)
print("After appending :", alist)
alist.append(3)
print("After appending :", alist)
# extend : passing multiple values
alist.extend([56,5343,43,9])
print("After extending :", alist)
getcount = alist.count(10)
print("count() :", getcount)
# insert( where to insert, what to insert)
alist.insert(0,5)
print("After inserting :", alist)
alist.insert(3,25)
print("After inserting :", alist)
alist.pop()  # will remove the last value
print("Afte pop() :", alist)
alist.pop(0)  # remove value at index 0
print("Afte pop() :", alist)
# remove the value 10
alist.remove(10)  ### 10 is the value
print("After remove() ", alist)
alist.sort()
print("sorting all the values :", alist)
alist.reverse()   ### or  alist[::-1]
print("reversing all the values :", alist)
# length of the list
print("total elements in the list :",len(alist))


alist.clear()
print(alist)



