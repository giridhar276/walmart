import requests
import json
import os
 
server = "https://api.github.com"
url = server + "/gists"
user = "giridharpython"
print("checking ", url, "using user:", user)


for file in os.listdir():
    if file.endswith(".py"):
        with open(file) as fobj:
            
            content = fobj.read()
            files = {
            "description": file + " testing",
            "public": "true",
            "user" : user,
            "files": {
            file: {
            "content": content
                }
              }
            }
            files["files"].update({file :{ "content":content}})
            r1 = requests.post(url, data=json.dumps(files), auth=(user,'Nolimits1@'))
            print(r1.json())
