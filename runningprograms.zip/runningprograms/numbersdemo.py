

print(10,20,30,40)

val = 10

print(val)
print("First value is :", val)

print(10,20,30,sep="*")


