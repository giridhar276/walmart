import string 
import random

# string with lowercase letters
lower = string.ascii_lowercase
# converting to list
lowerlist = list(lower)
# string with uppercase letters
upper = string.ascii_uppercase
upperlist = list(upper)


numbers = string.digits
numlist = list(numbers)

symbols = string.punctuation
symlist = list(symbols)

random.shuffle(lowerlist)
list1 = random.choices(lowerlist, k=3)

random.shuffle(upperlist)
list2 = random.choices(upperlist, k=3)


random.shuffle(numlist)
list3 = random.choices(numlist, k=2)
print(list3)
random.shuffle(symlist)
list4 = random.choices(symlist, k=2)

shuffled = list1 + list2 + list3 +list4
print(shuffled)
random.shuffle(shuffled)
# converting list to the string
password = "".join(shuffled)
print(password)
