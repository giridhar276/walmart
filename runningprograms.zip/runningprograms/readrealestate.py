
import urllib.request

link = "http://samplecsvs.s3.amazonaws.com/Sacramentorealestatetransactions.csv"
filename = link.split("/")[-1]

urllib.request.urlretrieve(link,filename)


# read operation  : reading line by line
with open(filename,"r") as fobj:
    for line in fobj:
        line = line.strip()
        print(line)
