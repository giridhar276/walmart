
import re
#  re is used to search, substitute, findall,match

with open("languages.txt","r") as fobj:
    for line in fobj:
        line = line.strip()
        if re.search("^python$", line):
            print(line)
