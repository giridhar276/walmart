

from github3 import login

gh = login("giridhar@gmail.com", "Nolimits1@")
gists = [g for g in gh.iter_gists()]
