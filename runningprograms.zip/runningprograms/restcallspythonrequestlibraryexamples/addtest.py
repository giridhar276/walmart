user = "giri"
mydata = "abc"
files = {
    "description": "2nd test",
    "public": "true",
    "user" : user,
    "files": {
    "githubtest0.py": {
    "content": mydata
        },
    "githubtest2.py": {
    "content": mydata
        }
      }
}


#files['files']["newfile"]["content"] = "tempdata"

#print(files)

files["files"].update({"newfile.py" :{ "content":"sample"}})

print(files)

