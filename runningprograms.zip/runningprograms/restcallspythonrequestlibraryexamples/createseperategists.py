
   
import requests
import json
import os
 
server = "https://api.github.com"
url = server + "/gists"
user = "giridharpython"
print("checking ", url, "using user:", user)


for file in os.listdir():
    with open(file) as fobj:
        content = fobj.read()
        files = {
        "description": file + " testing",
        "public": "true",
        "user" : user,
        "files": {
        file: {
        "content": content
            }
          }
        }
        files["files"].update({file :{ "content":content}})
    r1 = requests.post(url, data=json.dumps(files), auth=(user,'97d5fe08be91bc0e6aea4cad48561f1cf322bc88'))
    print(r1.json())
