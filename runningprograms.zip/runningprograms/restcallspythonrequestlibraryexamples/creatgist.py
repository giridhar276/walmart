   
import requests
import json

server = "https://api.github.com"
url = server + "/gists"
user = "giridhar276"
#passwd = getpass.getpass('Password:')
print("checking ", url, "using user:", user)

local_file = "githubtest0.py"
with open(local_file) as fh:
    mydata = fh.read()
files = {
    "description": "rest api - giri testing",
    "public": "true",
    "user" : user,
    "files": {
    "githubtest0.py": {
    "content": mydata
        }
      }
}
r1 = requests.post(url, data=json.dumps(files), auth=(user,'97d5fe08be91bc0e6aea4cad48561f1cf322bc88'))
print(r1.json())
