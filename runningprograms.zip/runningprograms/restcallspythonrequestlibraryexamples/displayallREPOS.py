    
import requests
import json
 

server = "https://api.github.com"
url = server + "/gists"


r = requests.get(url, auth=('giridharpython','97d5fe08be91bc0e6aea4cad48561f1cf322bc88'))

#print(r.text)


data = json.loads(r.text)

for element in data:
    print(element)
    print("-------------")