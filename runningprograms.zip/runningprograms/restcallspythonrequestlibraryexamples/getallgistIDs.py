import getopt, sys, os, errno  
import getpass    
import requests
import json
from requests.auth import HTTPBasicAuth


r = requests.get('https://api.github.com/users/giridhar276/gists', auth=('giridhar276','aa6c52f46d9a1b80d0421d84c282203ac73497a1'))
print(r.status_code)

server = "https://api.github.com"
url = server + "/gists"
user = "giridhar276"

info = json.loads(r.text)
for item in info:
    print(item)

    gid = item["id"]
    print(gid)
    
    url = server + "/gists/" + gid

    r1 = requests.delete(url, auth=HTTPBasicAuth(user,'aa6c52f46d9a1b80d0421d84c282203ac73497a1'))
    print(r1)
    #print(r1.text)

