'''
The os.system(command) method executes the command in subshell.

The subprocess.Popen(command_args, …..) method executes the command
args as new process (child process).
You can send / receive data to stdout /stdin using communicate() of Popen object.

The main difference between these two methods is os.system returns the
status code and subprocess.Popen returns the Popen object.
'''

import os

status = os.system("python creatgithub.py")
print(status)




import shlex
import subprocess
cmd = 'python program.py'
args = shlex.split(cmd)
print(args)

process = subprocess.Popen(args, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
stdout, stderr = process.communicate()

print(stdout.decode('utf-8'))

