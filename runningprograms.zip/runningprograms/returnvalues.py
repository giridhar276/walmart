

def display():
    return 1,"python"


values = display()
print(values)
