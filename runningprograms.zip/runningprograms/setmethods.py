

aset = {"google","facebook","linkedin"}
bset = {"linkedin","yahoo"}

print(aset.union(bset))
print(aset.intersection(bset))

print(aset.isdisjoint(bset))

print(aset.issubset(bset))

print(bset.issubset(aset))

print(aset.difference(bset))  # A - B

print(bset.difference(aset))  # B-A

aset.add("google")
print("After adding :", aset)

