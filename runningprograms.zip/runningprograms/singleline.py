
def getsquare(val):
    return val * val


value = getsquare(5)
print(value)


# using lambda
# lambda is the replacement for single line function
# lambda is an inline function
# the function body will be substituted in the function call itself


# SYNTAX :        functioname = lambda variables : expression

getsquare = lambda x : x * x
value = getsquare(5)
print(value)

toupper = lambda x : x.upper()
value = toupper("python")
print(value)


getsum = lambda x,y,z : x + y + z
total = getsum(10,20,30)
print(total)
