name = "python programming"
print(name.capitalize())
print(name.upper())
print(name.lower())
print(name.center(40))
print(name.center(40,"*"))
print(name.replace("python","ruby"))
print(name.count("p"))
# -1 if not exsiting
print(name.find("z"))
# will return index of the substr
print(name.find("y"))
aname = "I love {} and {}"
print(aname.format("spark","spark"))
print(name.isalnum())
print(name.isupper())
aname= "   python  "
print(aname.strip())

name = "scala programming"
output= name.split(" ")
print("After split() :", output)

name = "python"
print(name.rjust(15))


