

name = "python programming"
# string[start:stop:step]
print(name)
print(name[0])
print(name[1])
print(name[0:10])
print(name[4:15])
print(name[:])
print(name[0:15:2])
print(name[::])
print(name[::3])
print(name[1::2])
print(name[::4])    
print(name[-1])
print(name[-4:-1])
print(name[::-1]) # string reverse
