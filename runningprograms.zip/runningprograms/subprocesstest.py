#method1
import os

print(os.system("dir"))



# method2
import subprocess

output = subprocess.getoutput("dir")
print(output)