

atup = (10,20,30,40)

print(atup)

#atup[0] = 1000

print("After modifying :", atup)