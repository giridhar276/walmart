# metho1
def update(x):
    return x + 5
alist =[10,20,30,40,50]
blist = []
for val in alist:
    updateval = update(val)
    blist.append(updateval)
print(blist)    

#method2
alist =[10,20,30,40,50]
def update(x):
    return x + 5
print(list(map(update,alist)))

#method3
alist =[10,20,30,40,50]
print(list(map(lambda x:x + 5,alist)))

#method4
alist =[10,20,30,40,50]
blist = [  val + 5   for val in alist]
print(blist)

alist = ["google","oracle","microsoft"]
blist = [ "http://" + val + ".com" for val in alist]
print(blist)