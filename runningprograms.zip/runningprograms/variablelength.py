#variable length
#  * is the tuple
def display(*info):
    for val in info:
        print(val)

display(10,20,30,30,40,40,50,404,45)


## if any object is prefixed with ** it is dictionary
def displayvalues(**book):
    for key in book:
        print(key, book[key])

displayvalues(chap1 = 10 , chap2 = 20)
