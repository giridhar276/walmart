
# using while loop
count = 1
while count <=10:
    print(count)
    count = count + 1

# while with list
count = 0
alist =[10,20,30,40]
while count < len(alist):
    print(alist[count])
    count = count + 1
