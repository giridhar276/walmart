import pymysql
from openpyxl import Workbook
import time
import sys

try:  
    wb = Workbook()  
    ws = wb.active
    with pymysql.connect(host="localhost",port = 3306,user="root",password = "password",database = "boa") as db:
    
            query = "select * from realestate"
            # executing the query
            db.execute(query)
            for record in db.fetchall():
                #print(record)
                ws.append(record)
                    
    filename = time.strftime("%d_%b_%Y.xlsx")                
except Exception as error:
    print(error) 
    print(sys.exc_info())
else:
    wb.save(filename)
                
    